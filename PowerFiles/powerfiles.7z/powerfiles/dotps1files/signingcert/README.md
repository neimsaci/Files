# signingcert.ps1
Simple script that create self-signed sertificate
