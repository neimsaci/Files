<#
    Maigurs Stalidzans
    Simple script that create self-signed certificate and save it in necessary Cert Store location.
    THIS SCRIPT REQUIRES ELEVATED PERMISSIONS in order to store certificate in 'Cert:\LocalMachine\My'
#>

$Params = @{ 
	Subject = $(Read-Host "Enter name for your certificate")
	Type = 'CodeSigning'
	CertstoreLocation = 'Cert:\LocalMachine\My'
	HashAlgorithm = 'Sha512'
	FriendlyName = $(Read-Host "Create name that will indicate certificate purpose") 
}

$Cert = New-SelfSignedCertificate @Params -NotAfter (Get-Date).AddMonths(2) -KeyLength 16384
