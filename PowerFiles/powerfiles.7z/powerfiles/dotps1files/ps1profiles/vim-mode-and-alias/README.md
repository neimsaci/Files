# microsoft.powershell_profile.ps1
PowerShell profile that enables vi mode
