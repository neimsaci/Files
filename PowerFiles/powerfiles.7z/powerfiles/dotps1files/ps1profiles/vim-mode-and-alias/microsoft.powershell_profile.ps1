# Create alias that will allow to launch  neovim with vim and vi commands.
New-Alias -Name vi -Value     'C:\Program Files\Neovim\bin\nvim.exe'
New-Alias -Name vim -Value     'C:\Program Files\Neovim\bin\nvim.exe'

# EnabLing vim mode in PowerShell
Set-PSReadLineOption -EditMode vi
