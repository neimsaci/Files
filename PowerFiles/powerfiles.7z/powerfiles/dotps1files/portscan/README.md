# portscan.ps1
Simple PowerShell script for network port scanning. Currently only TCP protocol is supported.\
Hopefully I will develop somewhat useful utility over time, as I learn PowerShell.\
This script is based on resources that can be found here:\
[adamcouch.co.uk](https://www.adamcouch.co.uk/conducting-powershell-port-scan/#:~:text=Using%20PowerShell%20to%20conduct%20a%20simple%20port%20scan,outbound%20to%20the%20internet%20using%20a%20public%20IP. "Conducting PowerShell port scan")\
[SANS](https://www.sans.org/blog/pen-test-poster-white-board-powershell-built-in-port-scanner/ "PowerShell built-in port scanner")
