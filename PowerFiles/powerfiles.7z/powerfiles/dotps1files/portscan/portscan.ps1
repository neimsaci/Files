<#
	This is code from original sources for further reference:
	
	SANS:
	1..1024 | % {echo ((new-object Net.Sockets.TcpClient).Connect("10.0.0.100",$_)) "Port $_ is open!"} 2>$null
	foreach ($ip in 1..20) {Test-NetConnection -Port 80 -InformationLevel "Detailed" 192.168.1.$ip}
	1..20 | % { $a = $_; 1..1024 | % {echo ((new-object Net.Sockets.TcpClient).Connect("10.0.0.$a",$_)) "Port $_ is open!"} 2>$null}
	1..1024 | % {echo ((new-object Net.Sockets.TcpClient).Connect("allports.exposed",$_)) "Port $_ is open!" } 2>$null
	1..1024 | % {echo ((new-object Net.Sockets.TcpClient).Connect("10.0.0.100",$_)) "Port $_ is open!"} 2>$null
	foreach ($ip in 1..20) {Test-NetConnection -Port 80 -InformationLevel "Detailed" 192.168.1.$ip}
	1..20 | % { $a = $_; 1..1024 | % {echo ((new-object Net.Sockets.TcpClient).Connect("10.0.0.$a",$_)) "Port $_ is open!"} 2>$null}
	1..20 | % { $a = $_; write-host "------"; write-host "10.0.0.$a"; 22,53,80,445 | % {echo ((new-object Net.Sockets.TcpClient).Connect("10.0.0.$a",$_)) "Port $_ is open!"} 2>$null}
	1..1024 | % {echo ((new-object Net.Sockets.TcpClient).Connect("allports.exposed",$_)) "Port $_ is open" } 2>$null

	adamcouch.co.uk:
	$Server = Read-Host -Prompt 'Input your target IP/host' ; 1..65536 | % {$test= new-object system.Net.Sockets.TcpClient; $wait = $test.beginConnect("$Server",$_,$null,$null); ($wait.asyncwaithandle.waitone(250,$false)); if ($test.Connected){echo "$_ open"}else{echo "$_ closed"}} | select-string " "
	$Server = Read-Host -Prompt 'Input your target IP/host' ; 80, 445, 3389 | % {$test= new-object system.Net.Sockets.TcpClient; $wait = $test.beginConnect("$Server",$_,$null,$null); ($wait.asyncwaithandle.waitone(250,$false)); if ($test.Connected){echo "$_ open"}else{echo "$_ closed"}} | select-string " "
#>

# IP options
$ip = read-host -prompt 'Enter ip '

# Port options
$startport = read-host -prompt 'Enter starting port nr '
$endport = read-host -prompt 'Enter ending port nr '
$range = $startport..$endport

# Connection options
$range | % {$scan = new-object net.sockets.tcpclient; $wait = $scan.beginconnect("$ip", $_, $null, $null); ($wait.asyncwaithandle.waitone(250, $false)); if($scan.connected) { echo "port $_ is open" } else { echo "port $_ is closed" }} | select-string " "
